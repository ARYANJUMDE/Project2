'''
stone=1
paper=-1
scissor=0
'''
import random
Dictionary={
    "stone":1,
    "paper":-1,
    "scissor":0
}
yourinput=input("Enter Your Input:")

computerinput=random.choice(list(Dictionary.keys()))
#Storing Inputs in you and com variable
you=Dictionary[yourinput]
com=Dictionary[computerinput]
if(you==-1 and com==1):
    print("You Won Game")
elif(you==1 and com==0):
    print("You Won Game")
elif(you==0 and com==-1):
    print("You Won Game")
elif(you==1 and com==-1):
    print("You Lost Game")
elif(you==0 and com==1):
    print("You Lost Game")
elif(you==-1 and com==0):
    print("You Lost Game")
    
else:
    print("Game Is Draw")

print("Computer Choice: "+computerinput)


